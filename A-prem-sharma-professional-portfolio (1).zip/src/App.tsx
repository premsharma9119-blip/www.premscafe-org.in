import { useState, useEffect } from 'react';

const NAV_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'experience', label: 'Experience' },
  { id: 'skills', label: 'Skills' },
  { id: 'services', label: 'Services' },
  { id: 'projects', label: 'Projects' },
  { id: 'social', label: 'Social' },
  { id: 'contact', label: 'Contact' },
];

const SERVICES = [
  { title: "Official Letter Drafting", desc: "Precise, protocol-based government letters with perfect formatting and language.", icon: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M10 16H8 M16 12H8 M13 16h5" },
  { title: "Government Notesheets", desc: "Standard noting, drafting, and file movement as per Rajasthan govt manual.", icon: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2 M10 2a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h0a2 2 0 0 1-2-2V2z" },
  { title: "Hindi-English Translation", desc: "Official bilingual translation for administrative and technical documents.", icon: "M5 8l6 0 M4 6l8 0 M8 2v10 M12 12l2 2 4-4 M21 12h-4 M18 9v6" },
  { title: "Resume Designing", desc: "ATS-optimized, premium resumes for govt & corporate roles.", icon: "M16 7a4 4 0 1 1-8 0a4 4 0 0 1 8 0z M12 14a7 7 0 0 0-7 7h14a7 7 0 0 0-7-7z" },
  { title: "Portfolio Website", desc: "Personal branding sites for professionals — clean, fast, SEO-ready.", icon: "M3 9l9-7l9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10" },
  { title: "AI Prompt Writing", desc: "Advanced prompt engineering for ChatGPT, Midjourney & workflow automation.", icon: "M9.5 2a6.5 6.5 0 1 0 0 13a6.5 6.5 0 0 0 0-13z M12 8v4 M8 12h4 M18 4v2 M20 6h-2 M22 12h-2 M20 18h-2 M18 20v-2" },
  { title: "Graphic Designing", desc: "Minimal corporate creatives, social posts, and official presentations.", icon: "M12 19l7-7a2.5 2.5 0 0 0 0-3.5a2.5 2.5 0 0 0-3.5 0l-7 7v4h4z M6 18H4a2 2 0 0 1-2-2v-1" },
  { title: "YouTube Thumbnails", desc: "High-CTR thumbnail design with bold typography and visual hierarchy.", icon: "M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.6a2.78 2.78 0 0 0 1.94 2C5.12 20 12 20 12 20s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z M9.75 15.5V8.5L16 12z" },
  { title: "Instagram Branding", desc: "Grid planning, reel covers, story templates for personal brands.", icon: "M16 4H8A4 4 0 0 0 4 8v8a4 4 0 0 0 4 4h8a4 4 0 0 0 4-4V8a4 4 0 0 0-4-4z M12 15a3 3 0 1 0 0-6a3 3 0 0 0 0 6z M17.5 6.5h.01" },
  { title: "Website Development", desc: "Full-stack sites with React, modern UI, and performance focus.", icon: "M16 18l6-6l-6-6 M8 6l-6 6l6 6 M10 4l4 16" },
];

const PROJECTS = [
  { title: "Government Office Documentation", cat: "Administration", desc: "End-to-end digitization of 500+ official files, letters & committee reports for AP Office.", tags: ["Govt Process", "Documentation"], color: "from-[#003366] to-[#0055AA]", year: "2024" },
  { title: "RUHS Administrative Files", cat: "System Design", desc: "Structured file management system reducing retrieval time by 60% for RUHS CMS.", tags: ["File System", "Efficiency"], color: "from-[#0055AA] to-[#00C2FF]", year: "2024" },
  { title: "AI Prompt Engineering Hub", cat: "AI Creator", desc: "Curated library of 200+ production-ready prompts for drafting, translation & design.", tags: ["AI", "Prompts", "Automation"], color: "from-[#001A33] to-[#003366]", year: "2025" },
  { title: "Instagram Personal Branding", cat: "Creative", desc: "Built @digitaljaipur brand identity - 3 content pillars, 12k+ organic reach.", tags: ["Branding", "Content"], color: "from-[#0066FF] to-[#00C2FF]", year: "2025" },
  { title: "Portfolio & Resume System", cat: "Web Dev", desc: "Portfolio websites for 20+ professionals, integrated with ATS resume generator.", tags: ["React", "Tailwind", "Portfolio"], color: "from-slate-800 to-[#003366]", year: "2025" },
  { title: "Office Automation Scripts", cat: "Automation", desc: "Excel + script automation for notesheet formatting, letter numbering & record logs.", tags: ["Automation", "Excel", "Scripts"], color: "from-[#003366] to-slate-900", year: "2024" },
];

const SKILL_GROUPS = [
  { 
    name: "Govt Administration", 
    icon: "🏛️",
    skills: ["Official Letter Drafting", "Note Sheet & Drafting", "Committee Reports", "Record Management", "File Movement", "RajKaj / e-Office"]
  },
  { 
    name: "AI & Automation", 
    icon: "🤖",
    skills: ["Prompt Engineering", "ChatGPT Workflow", "AI Content Creation", "Midjourney / Ideogram", "Office Automation", "Text-to-Design"]
  },
  { 
    name: "Web Development", 
    icon: "💻",
    skills: ["React / Next.js", "Tailwind CSS", "Portfolio Sites", "Responsive UI", "No-Code Tools", "SEO Basics"]
  },
  { 
    name: "Digital Creative", 
    icon: "🎨",
    skills: ["Graphic Design", "Thumbnail Design", "Instagram Strategy", "Canva Pro", "Brand Identity", "Hindi-English Translation"]
  },
];

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeId, setActiveId] = useState('home');
  const [instaTab, setInstaTab] = useState('feed');
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('ps-theme') as 'light' | 'dark' | null;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setTheme(saved || (prefersDark ? 'dark' : 'light'));
  }, []);

  useEffect(() => {
    localStorage.setItem('ps-theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActiveId(e.target.id);
        });
      },
      { rootMargin: '-40% 0px -50% 0px' }
    );
    NAV_ITEMS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen font-[Instrument_Sans] antialiased selection:bg-[#00C2FF]/30 transition-colors duration-500 ${isDark ? 'bg-[#060E1E] text-zinc-100' : 'bg-[#F5F7FA] text-[#222222]'}`}>
      <style>{`
        html { scroll-behavior: smooth; }
        * { font-family: "Instrument Sans", system-ui, -apple-system, sans-serif; }
        .mono { font-family: "Fragment Mono", monospace; }
        .glass { backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); }
        .grid-bg {
          background-image: linear-gradient(to right, ${isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,51,102,0.06)'} 1px, transparent 1px),
                            linear-gradient(to bottom, ${isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,51,102,0.06)'} 1px, transparent 1px);
          background-size: 32px 32px;
        }
      `}</style>

      {/* NAV */}
      <header className={`fixed top-0 inset-x-0 z-50 border-b transition-all ${isDark ? 'bg-[#060E1E]/70 border-white/[0.08] glass' : 'bg-white/70 border-[#003366]/[0.08] glass'}`}>
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 h-[72px] flex items-center justify-between">
          <a href="#home" className="flex items-center gap-3 group">
            <div className="h-9 w-9 rounded-[10px] bg-[#003366] grid place-items-center text-white font-bold text-[15px] tracking-tight group-hover:bg-[#0055AA] transition-colors">PS</div>
            <div className="leading-none hidden sm:block">
              <div className="flex items-baseline gap-1.5">
                <span className={`font-semibold tracking-tight text-[15px] ${isDark ? 'text-white' : 'text-[#003366]'}`}>digitaljaipur.prem.in</span>
                <span className="h-1 w-1 rounded-full bg-[#00C2FF] animate-pulse inline-block" />
              </div>
              <div className={`mono text-[10px] tracking-widest uppercase opacity-60 ${isDark ? 'text-zinc-400' : 'text-[#003366]/70'}`}>Official Portfolio • 2026</div>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-1.5">
            {NAV_ITEMS.map(item => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={`px-3.5 py-2 rounded-full text-[13.5px] font-medium transition-all ${activeId === item.id ? (isDark ? 'bg-white text-black' : 'bg-[#003366] text-white') : (isDark ? 'text-zinc-400 hover:text-white hover:bg-white/10' : 'text-[#003366]/70 hover:text-[#003366] hover:bg-[#003366]/5')}`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setTheme(isDark ? 'light' : 'dark')}
              className={`h-9 w-9 grid place-items-center rounded-full border transition-colors ${isDark ? 'border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10' : 'border-[#003366]/10 bg-white text-[#003366] hover:bg-[#003366]/5'}`}
              aria-label="Toggle theme"
            >
              {isDark ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="5"/><path d="M12 1v2 M12 21v2 M4.2 4.2l1.4 1.4 M18.4 18.4l1.4 1.4 M1 12h2 M21 12h2 M4.2 19.8l1.4-1.4 M18.4 5.6l1.4-1.4"/></svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              )}
            </button>

            <a href="#contact" className="hidden sm:inline-flex h-9 px-5 items-center justify-center rounded-full bg-[#0066FF] text-white text-[13.5px] font-semibold hover:bg-[#0055CC] transition-colors shadow-[0_0_20px_rgba(0,102,255,0.25)]">
              Let's Talk
            </a>

            <button onClick={() => setMenuOpen(!menuOpen)} className={`lg:hidden h-9 w-9 grid place-items-center rounded-full border ${isDark ? 'border-white/10 bg-white/5' : 'border-[#003366]/10 bg-white'}`}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                {menuOpen ? <path d="M18 6L6 18 M6 6l12 12" /> : <><path d="M3 6h18 M3 12h18 M3 18h18" /></>}
              </svg>
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className={`lg:hidden border-t ${isDark ? 'bg-[#060E1E] border-white/10' : 'bg-white border-black/5'} px-6 py-6`}>
            <div className="grid gap-1">
              {NAV_ITEMS.map(i => (
                <a key={i.id} href={`#${i.id}`} onClick={()=>setMenuOpen(false)} className={`py-3 text-[15px] font-medium border-b last:border-0 ${isDark ? 'border-white/5 text-zinc-300' : 'border-black/5 text-[#003366]/80'}`}>{i.label}</a>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>
        {/* HERO */}
        <section id="home" className="relative pt-[72px] overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-[0.6]" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#F5F7FA] dark:to-[#060E1E] pointer-events-none" style={{ background: isDark ? `radial-gradient(800px 600px at 20% 10%, rgba(0,194,255,0.12), transparent), radial-gradient(600px 400px at 90% 20%, rgba(0,51,102,0.25), transparent)` : `radial-gradient(800px 600px at 20% 10%, rgba(0,194,255,0.12), transparent), radial-gradient(600px 400px at 90% 20%, rgba(0,51,102,0.12), transparent)` }} />

          <div className="relative mx-auto max-w-[1280px] px-6 lg:px-8 py-14 lg:py-24">
            <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-12 lg:gap-10 items-start">
              {/* Left */}
              <div>
                <div className={`inline-flex items-center gap-2.5 rounded-full border px-3.5 py-1.5 text-[11px] font-medium tracking-wide mono uppercase ${isDark ? 'bg-white/[0.06] border-white/10 text-zinc-300' : 'bg-white border-[#003366]/10 text-[#003366]/70 shadow-sm'}`}>
                  <span className="relative flex h-2 w-2"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span><span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span></span>
                  Available for freelance • Working at RUHS CMS
                </div>

                <div className="mt-8">
                  <h1 className="text-[42px] sm:text-[64px] lg:text-[84px] font-[700] leading-[0.85] tracking-[-0.04em]">
                    <span className={`${isDark ? 'text-white' : 'text-[#003366]'} block`}>PREM</span>
                    <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#003366] via-[#0055AA] to-[#00C2FF] dark:from-white dark:via-[#89C4FF] dark:to-[#00C2FF]">SHARMA</span>
                  </h1>
                  <div className="mt-5 flex flex-wrap items-center gap-3">
                    <div className={`h-px w-12 ${isDark ? 'bg-white/20' : 'bg-[#003366]/20'}`} />
                    <p className={`mono text-[12px] sm:text-[13px] tracking-[0.18em] uppercase font-medium ${isDark ? 'text-zinc-400' : 'text-[#003366]/60'}`}>DEO | AI Creator | Government Professional</p>
                  </div>
                </div>

                <div className="mt-8 max-w-[560px]">
                  <p className={`text-[18px] sm:text-[20px] leading-[1.35] font-[500] tracking-tight ${isDark ? 'text-zinc-200' : 'text-[#222222]'}`}>
                    Combining <span className="relative inline-block"><span className="relative z-10">Government Administration</span><span className="absolute bottom-1 left-0 right-0 h-[8px] bg-[#00C2FF]/20 -rotate-1" /></span> with AI Innovation.
                  </p>
                  <div className={`mt-6 rounded-[16px] border p-4 sm:p-5 flex gap-4 ${isDark ? 'bg-white/[0.03] border-white/[0.06] glass' : 'bg-white border-[#003366]/[0.06] shadow-[0_8px_32px_rgba(0,51,102,0.06)]'}`}>
                    <div className={`h-10 w-10 rounded-full grid place-items-center shrink-0 ${isDark ? 'bg-white/10 text-white' : 'bg-[#003366] text-white'}`}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 9l9-7l9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10"/></svg>
                    </div>
                    <div>
                      <div className={`mono text-[10px] tracking-widest uppercase ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Currently Working In</div>
                      <div className={`mt-1 text-[14px] font-semibold leading-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>Additional Principal Office</div>
                      <div className={`text-[13px] ${isDark ? 'text-zinc-400' : 'text-[#222222]/70'}`}>RUHS College of Medical Sciences, Jaipur, Rajasthan</div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-3">
                  <a href="#projects" className="h-[44px] px-7 inline-flex items-center justify-center rounded-full bg-[#003366] dark:bg-white text-white dark:text-black text-[14px] font-semibold hover:opacity-90 transition-opacity gap-2">
                    View Work <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14 M13 5l7 7-7 7"/></svg>
                  </a>
                  <a href="#contact" className={`h-[44px] px-7 inline-flex items-center justify-center rounded-full border text-[14px] font-semibold transition-colors ${isDark ? 'border-white/15 text-white hover:bg-white/10' : 'border-[#003366]/15 text-[#003366] hover:bg-[#003366]/5'}`}>
                    Contact • 7878559853
                  </a>
                </div>

                <div className={`mt-12 grid grid-cols-3 gap-6 border-t pt-8 max-w-[440px] ${isDark ? 'border-white/10' : 'border-[#003366]/10'}`}>
                  {[{k:"3+", v:"Years in Govt\nAdministration"},{k:"500+", v:"Official Docs\nDrafted"},{k:"20+", v:"Websites &\nBrands Built"}].map((s,i)=>(
                    <div key={i}>
                      <div className={`text-[32px] font-bold tracking-tight leading-none ${isDark ? 'text-white' : 'text-[#003366]'}`}>{s.k}</div>
                      <div className={`mt-2 mono text-[10px] leading-[1.2] uppercase tracking-wide whitespace-pre ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>{s.v}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Card */}
              <div className="lg:sticky lg:top-[96px]">
                <div className={`relative rounded-[24px] border overflow-hidden ${isDark ? 'bg-white/[0.04] border-white/[0.08] glass' : 'bg-white border-[#003366]/[0.06] shadow-[0_24px_64px_rgba(0,51,102,0.12)]'}`}>
                  <div className="absolute inset-0 opacity-[0.04]" style={{backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`}}/>
                  <div className={`absolute -top-24 -right-24 h-[320px] w-[320px] rounded-full blur-[80px] ${isDark ? 'bg-[#00C2FF]/20' : 'bg-[#00C2FF]/15'}`} />
                  
                  <div className="relative p-7 sm:p-8">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-4 items-center">
                        <div className="relative">
                          <div className="h-[64px] w-[64px] rounded-[16px] bg-gradient-to-br from-[#003366] to-[#0055AA] grid place-items-center text-white font-bold text-[22px]">PS</div>
                          <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-emerald-500 border-2 border-white dark:border-[#0D1A30] grid place-items-center">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="white" stroke="white"><path d="M5 12l5 5l10-10" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                          </div>
                        </div>
                        <div>
                          <div className={`font-semibold text-[16px] tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>Prem Sharma</div>
                          <div className={`mono text-[11px] ${isDark ? 'text-zinc-400' : 'text-[#003366]/60'}`}>@digitaljaipur • Jaipur</div>
                          <div className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide">
                            <span className="h-1 w-1 rounded-full bg-emerald-500 animate-pulse" /> Active Now
                          </div>
                        </div>
                      </div>
                      <div className={`h-8 w-8 rounded-full grid place-items-center ${isDark ? 'bg-white/10' : 'bg-[#003366]/5'}`}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                      </div>
                    </div>

                    <div className={`mt-8 rounded-[16px] border p-4 ${isDark ? 'bg-[#060E1E]/50 border-white/[0.06]' : 'bg-[#F5F7FA] border-[#003366]/5'}`}>
                      <div className={`mono text-[10px] uppercase tracking-widest mb-3 ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Focus Stack</div>
                      <div className="flex flex-wrap gap-2">
                        {["Govt Drafting", "AI Prompts", "React", "Branding", "RajKaj"].map(t=>(
                          <span key={t} className={`px-3 py-1.5 rounded-full text-[11px] font-medium border ${isDark ? 'bg-white/5 border-white/10 text-zinc-300' : 'bg-white border-[#003366]/10 text-[#003366]/80'}`}>{t}</span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6 space-y-3">
                      {[
                        {label:"Email", value:"premsharma.9119@gmail.com", icon:"M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6"},
                        {label:"Phone / WhatsApp", value:"+91 78785 59853", icon:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.68A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.77.63 2.61a2 2 0 0 1-.45 2.11L9 9a16 16 0 0 0 6 6l.54-.29a2 2 0 0 1 2.11-.45c.84.3 1.71.51 2.61.63A2 2 0 0 1 22 16.92z"},
                        {label:"Location", value:"Jaipur, Rajasthan — 302033", icon:"M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"},
                      ].map((row)=>(
                        <div key={row.label} className={`flex items-center gap-3 rounded-[12px] p-3 border ${isDark ? 'border-white/5 bg-white/[0.02] hover:bg-white/[0.04]' : 'border-[#003366]/[0.06] bg-white hover:bg-[#F5F7FA]'} transition-colors`}>
                          <div className={`h-9 w-9 rounded-full grid place-items-center ${isDark ? 'bg-white/10' : 'bg-[#003366]/5 text-[#003366]'}`}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d={row.icon}/></svg></div>
                          <div className="min-w-0">
                            <div className={`mono text-[10px] uppercase tracking-wide ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>{row.label}</div>
                            <div className={`text-[13px] font-medium truncate ${isDark ? 'text-zinc-200' : 'text-[#222]'}`}>{row.value}</div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 grid grid-cols-3 gap-2">
                      {[
                        {name:"Instagram", handle:"@digitaljaipur"},
                        {name:"LinkedIn", handle:"Prem Sharma"},
                        {name:"GitHub", handle:"prem-sharma"},
                      ].map(s=>(
                        <a key={s.name} href="#" className={`rounded-[12px] border p-3 text-center hover:scale-[1.02] transition-transform ${isDark ? 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]' : 'bg-[#F5F7FA] border-[#003366]/5 hover:bg-white'}`}>
                          <div className={`mono text-[10px] uppercase ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>{s.name}</div>
                          <div className={`text-[11px] font-medium mt-1 truncate ${isDark ? 'text-zinc-300' : 'text-[#003366]'}`}>{s.handle}</div>
                        </a>
                      ))}
                    </div>
                  </div>

                  <div className={`h-[48px] flex items-center justify-between px-7 border-t text-[11px] mono tracking-wide ${isDark ? 'border-white/5 bg-white/[0.02] text-zinc-500' : 'border-[#003366]/5 bg-[#F5F7FA]/50 text-[#003366]/50'}`}>
                    <span>© 2026 • Digital Jaipur</span>
                    <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-emerald-500"/> Open to work</span>
                  </div>
                </div>

                {/* floating accent */}
                <div className={`hidden lg:flex mt-4 items-center gap-3 rounded-full border px-4 py-2 w-fit ${isDark ? 'bg-[#00C2FF]/10 border-[#00C2FF]/20 text-[#7AD9FF]' : 'bg-[#00C2FF]/10 border-[#00C2FF]/20 text-[#0055AA]'}`}>
                  <span className="h-6 w-6 rounded-full bg-[#00C2FF] grid place-items-center text-white"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16 5.5 20l2-7L2 9h7z"/></svg></span>
                  <span className="text-[12px] font-medium">Top Rated — Government Documentation Expert</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className={`relative border-t ${isDark ? 'border-white/5 bg-[#080E1E]' : 'border-[#003366]/5 bg-white'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
              <div>
                <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>01 — About Me</div>
                <h2 className={`mt-3 text-[32px] sm:text-[44px] font-semibold tracking-tight leading-[0.95] ${isDark ? 'text-white' : 'text-[#003366]'}`}>
                  Bridging <br /> Administration <br /> <span className={`italic font-normal ${isDark ? 'text-zinc-400' : 'text-[#0055AA]/70'}`}>& Innovation.</span>
                </h2>
              </div>
              <p className={`max-w-[420px] text-[15px] leading-[1.6] ${isDark ? 'text-zinc-400' : 'text-[#222]/70'}`}>
                I work at RUHS College of Medical Sciences, Jaipur. Day-time I manage official government files, night-time I build AI systems, portfolios & brands for professionals.
              </p>
            </div>

            <div className="grid lg:grid-cols-12 gap-8">
              <div className="lg:col-span-5">
                <div className={`rounded-[20px] border p-6 h-full ${isDark ? 'bg-white/[0.03] border-white/10' : 'bg-[#F5F7FA] border-[#003366]/5'}`}>
                  <div className="aspect-[4/3] rounded-[14px] overflow-hidden bg-gradient-to-br from-[#003366] to-[#00C2FF] relative">
                    <div className="absolute inset-0 grid-bg opacity-20" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="text-[64px] font-bold leading-none tracking-tight">RUHS</div>
                        <div className="mono text-[11px] tracking-[0.2em] uppercase mt-2 opacity-80">Medical Sciences • Jaipur</div>
                      </div>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                      <div className="rounded-full bg-white/90 backdrop-blur px-3 py-1 text-[11px] font-semibold text-[#003366]">Govt of Rajasthan</div>
                      <div className="h-8 w-8 rounded-full bg-white/90 grid place-items-center text-[#003366]"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-3">
                    <div className={`rounded-[12px] border p-4 ${isDark ? 'bg-[#060E1E] border-white/5' : 'bg-white border-[#003366]/5'}`}>
                      <div className={`text-[26px] font-bold ${isDark ? 'text-white' : 'text-[#003366]'}`}>100%</div>
                      <div className={`mono text-[10px] uppercase tracking-wide mt-1 ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>On-time file disposal</div>
                    </div>
                    <div className={`rounded-[12px] border p-4 ${isDark ? 'bg-[#060E1E] border-white/5' : 'bg-white border-[#003366]/5'}`}>
                      <div className={`text-[26px] font-bold ${isDark ? 'text-white' : 'text-[#003366]'}`}>AI x Govt</div>
                      <div className={`mono text-[10px] uppercase tracking-wide mt-1 ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Hybrid workflow expert</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7">
                <div className={`rounded-[20px] border p-7 sm:p-10 h-full ${isDark ? 'bg-white/[0.02] border-white/10' : 'bg-white border-[#003366]/5 shadow-[0_8px_40px_rgba(0,51,102,0.06)]'}`}>
                  <div className="flex gap-4">
                    <div className={`hidden sm:block h-[80px] w-[2px] shrink-0 rounded-full bg-gradient-to-b from-[#003366] to-transparent ${isDark ? 'from-white/60' : ''}`} />
                    <div>
                      <h3 className={`text-[22px] font-semibold leading-tight tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>I'm Prem Sharma, Data Entry Operator at Additional Principal Office, RUHS CMS.</h3>
                      <p className={`mt-4 text-[15px] leading-[1.7] ${isDark ? 'text-zinc-400' : 'text-[#222]/70'}`}>
                        With hands-on experience in Rajasthan Government file work, I handle official letters, note sheets, committee reports, and digital office automation. What makes me different — I don't just do data entry, I build systems.
                      </p>
                      <p className={`mt-4 text-[15px] leading-[1.7] ${isDark ? 'text-zinc-400' : 'text-[#222]/70'}`}>
                        Outside office hours, I work as an AI creator & web developer — designing portfolio websites, resume systems, Instagram branding, and teaching prompt engineering that saves 10+ hours/week in office work.
                      </p>

                      <div className="mt-8 grid sm:grid-cols-2 gap-4">
                        {[
                          {title:"Philosophy", text:"Government work needs precision, not just speed. I draft notes that clear in 1st review."},
                          {title:"Approach", text:"Minimal, corporate, protocol-followed — every page, every margin matters."},
                        ].map(c=>(
                          <div key={c.title} className={`rounded-[14px] border p-5 ${isDark ? 'bg-[#060E1E] border-white/5' : 'bg-[#F5F7FA] border-[#003366]/5'}`}>
                            <div className={`mono text-[10px] uppercase tracking-widest ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>{c.title}</div>
                            <div className={`mt-2 text-[14px] leading-[1.5] font-medium ${isDark ? 'text-zinc-300' : 'text-[#003366]/90'}`}>{c.text}</div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-8 flex flex-wrap gap-2">
                        {["Jaipur Based", "Hindi + English", "Available Freelance", "Government Verified"].map(tag=>(
                          <span key={tag} className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[12px] font-medium ${isDark ? 'bg-white/5 border-white/10 text-zinc-300' : 'bg-[#F5F7FA] border-[#003366]/10 text-[#003366]/70'}`}>
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* EXPERIENCE */}
        <section id="experience" className={`relative py-20 lg:py-28 ${isDark ? 'bg-[#060E1E]' : 'bg-[#F5F7FA]'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8">
            <div className="max-w-[720px] mx-auto text-center mb-14">
              <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>02 — Work Experience</div>
              <h2 className={`mt-3 text-[34px] sm:text-[48px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>Government experience, <br /> startup mindset.</h2>
            </div>

            <div className="max-w-[960px] mx-auto">
              <div className={`rounded-[24px] border overflow-hidden ${isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white border-[#003366]/5 shadow-[0_20px_60px_rgba(0,51,102,0.08)]'}`}>
                <div className={`grid md:grid-cols-[320px_1fr] border-b ${isDark ? 'border-white/5' : 'border-[#003366]/5'}`}>
                  <div className={`p-8 ${isDark ? 'bg-white/[0.02]' : 'bg-[#F5F7FA]'}`}>
                    <div className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-wide ${isDark ? 'bg-white text-black' : 'bg-[#003366] text-white'}`}>Current Role</div>
                    <h3 className={`mt-5 text-[22px] font-semibold leading-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>Data Entry Operator</h3>
                    <div className={`mt-2 text-[14px] ${isDark ? 'text-zinc-400' : 'text-[#003366]/70'}`}>RUHS College of Medical Sciences</div>
                    <div className={`mt-4 mono text-[11px] leading-[1.6] ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>
                      Additional Principal Office<br />Jaipur, Rajasthan<br />2023 — Present
                    </div>
                    <div className="mt-6 flex gap-2">
                      <div className={`h-9 w-9 rounded-full grid place-items-center ${isDark ? 'bg-white/10 text-white' : 'bg-[#003366] text-white'}`}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 7a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
                      <div className={`h-9 w-9 rounded-full grid place-items-center border ${isDark ? 'border-white/10 text-zinc-400' : 'border-[#003366]/10 text-[#003366]/60'}`}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
                    </div>
                  </div>
                  <div className="p-8">
                    <div className={`mono text-[10px] uppercase tracking-widest ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Department & Responsibilities</div>
                    <div className="mt-6 grid sm:grid-cols-2 gap-3">
                      {[
                        "Official Letter Drafting",
                        "Government Note Sheets",
                        "Committee Reports",
                        "Office Documentation",
                        "Record Management",
                        "Digital Office Work",
                        "Administrative Support",
                        "File Movement & Tracking"
                      ].map(item=>(
                        <div key={item} className={`flex items-center gap-3 rounded-[12px] border px-4 py-3 text-[13.5px] font-medium ${isDark ? 'bg-[#060E1E] border-white/5 text-zinc-300' : 'bg-[#F5F7FA] border-[#003366]/5 text-[#003366]/80'}`}>
                          <span className="h-5 w-5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 grid place-items-center shrink-0">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12l5 5l10-10"/></svg>
                          </span>
                          {item}
                        </div>
                      ))}
                    </div>

                    <div className={`mt-8 rounded-[14px] border p-5 flex gap-4 ${isDark ? 'bg-[#00C2FF]/5 border-[#00C2FF]/15' : 'bg-[#00C2FF]/5 border-[#00C2FF]/15'}`}>
                      <div className="h-10 w-10 rounded-full bg-[#00C2FF] text-white grid place-items-center shrink-0"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M12 16v-4 M12 8h.01"/></svg></div>
                      <div>
                        <div className={`text-[13px] font-semibold ${isDark ? 'text-white' : 'text-[#003366]'}`}>Impact Note</div>
                        <div className={`mt-1 text-[13px] leading-[1.5] ${isDark ? 'text-zinc-400' : 'text-[#003366]/70'}`}>Reduced average noting approval time from 3 days to same-day by creating bilingual templates and automation sheets adopted across office.</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className={`grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x ${isDark ? 'divide-white/5' : 'divide-[#003366]/5'}`}>
                  {[
                    {k:"99.2%", l:"Accuracy in official drafting"},
                    {k:"500+", l:"Files managed & archived"},
                    {k:"60%", l:"Faster retrieval via new system"},
                  ].map(s=>(
                    <div key={s.k} className="p-6 text-center">
                      <div className={`text-[22px] font-bold ${isDark ? 'text-white' : 'text-[#003366]'}`}>{s.k}</div>
                      <div className={`mono text-[11px] mt-1 ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>{s.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className={`border-t ${isDark ? 'border-white/5 bg-[#080E1E]' : 'border-[#003366]/5 bg-white'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="flex justify-between items-end flex-wrap gap-6 mb-12">
              <div>
                <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>03 — Skills & Expertise</div>
                <h2 className={`mt-3 text-[32px] sm:text-[44px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>Where govt process<br/>meets AI craft.</h2>
              </div>
              <div className={`text-[13px] mono px-4 py-2 rounded-full border ${isDark ? 'border-white/10 text-zinc-400' : 'border-[#003366]/10 text-[#003366]/60'}`}>Hover to explore • 4 domains</div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
              {SKILL_GROUPS.map(group=>(
                <div key={group.name} className={`group rounded-[20px] border p-6 transition-all hover:-translate-y-1 ${isDark ? 'bg-white/[0.03] border-white/10 hover:bg-white/[0.05] hover:border-white/15' : 'bg-[#F5F7FA] border-[#003366]/5 hover:bg-white hover:shadow-[0_12px_32px_rgba(0,51,102,0.08)] hover:border-[#003366]/10'}`}>
                  <div className="flex justify-between items-start">
                    <div className="text-[28px]">{group.icon}</div>
                    <div className={`h-7 w-7 rounded-full grid place-items-center border text-[12px] ${isDark ? 'border-white/10 text-zinc-500' : 'border-[#003366]/10 text-[#003366]/40'}`}>{group.skills.length}</div>
                  </div>
                  <h3 className={`mt-4 font-semibold text-[16px] tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>{group.name}</h3>
                  <div className="mt-5 space-y-2.5">
                    {group.skills.map(skill=>(
                      <div key={skill} className={`flex items-center gap-2.5 text-[13px] ${isDark ? 'text-zinc-400 group-hover:text-zinc-200' : 'text-[#222]/70 group-hover:text-[#003366]'}`}>
                        <span className={`h-[3px] w-[3px] rounded-full shrink-0 ${isDark ? 'bg-zinc-500' : 'bg-[#003366]/40'}`} />
                        {skill}
                      </div>
                    ))}
                  </div>
                  <div className={`mt-6 h-1 w-full rounded-full overflow-hidden ${isDark ? 'bg-white/5' : 'bg-[#003366]/5'}`}>
                    <div className="h-full w-[85%] bg-gradient-to-r from-[#003366] to-[#00C2FF] dark:from-white dark:to-[#00C2FF]" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className={`${isDark ? 'bg-[#060E1E]' : 'bg-[#F5F7FA]'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="max-w-[640px]">
              <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>04 — Services</div>
              <h2 className={`mt-3 text-[32px] sm:text-[48px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>I help professionals look <span className="text-[#00C2FF]">official</span> & premium.</h2>
              <p className={`mt-4 text-[15px] leading-[1.6] ${isDark ? 'text-zinc-400' : 'text-[#222]/60'}`}>From government drafting to AI-powered personal branding — services built on protocol + design system thinking.</p>
            </div>

            <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {SERVICES.map((s, idx)=>(
                <div key={s.title} className={`group relative rounded-[20px] border p-6 flex flex-col h-full transition-all hover:-translate-y-1 ${isDark ? 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]' : 'bg-white border-[#003366]/5 hover:shadow-[0_16px_40px_rgba(0,51,102,0.10)] hover:border-[#003366]/10'}`}>
                  <div className={`h-11 w-11 rounded-[12px] grid place-items-center border ${isDark ? 'bg-[#060E1E] border-white/10 text-white group-hover:bg-white group-hover:text-black' : 'bg-[#F5F7FA] border-[#003366]/5 text-[#003366] group-hover:bg-[#003366] group-hover:text-white'} transition-colors`}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d={s.icon}/></svg>
                  </div>
                  <h3 className={`mt-5 text-[15px] font-semibold leading-tight tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>{s.title}</h3>
                  <p className={`mt-2 text-[12.5px] leading-[1.5] flex-1 ${isDark ? 'text-zinc-500 group-hover:text-zinc-400' : 'text-[#222]/60 group-hover:text-[#222]/80'}`}>{s.desc}</p>
                  <div className="mt-5 flex items-center gap-2">
                    <span className={`mono text-[10px] uppercase tracking-wide px-2 py-1 rounded-full border ${isDark ? 'bg-white/5 border-white/10 text-zinc-400' : 'bg-[#F5F7FA] border-[#003366]/10 text-[#003366]/50'}`}>#{String(idx+1).padStart(2,'0')}</span>
                    <span className={`text-[12px] font-medium flex items-center gap-1 ${isDark ? 'text-zinc-300' : 'text-[#0055AA]'} group-hover:gap-2 transition-all`}>Explore <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14 M13 5l7 7-7 7"/></svg></span>
                  </div>
                </div>
              ))}
            </div>

            <div className={`mt-8 rounded-[16px] border p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${isDark ? 'bg-[#00C2FF]/5 border-[#00C2FF]/15' : 'bg-[#003366] text-white border-transparent'}`}>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-white/15 grid place-items-center"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M8 12l2 2 4-4"/></svg></div>
                <div>
                  <div className="text-[14px] font-semibold">Need bulk office work or personal branding?</div>
                  <div className={`text-[12px] ${isDark ? 'text-zinc-400' : 'text-white/70'}`}>Get govt-accurate drafts + premium design in 24-48h</div>
                </div>
              </div>
              <a href="#contact" className={`h-10 px-5 rounded-full inline-flex items-center justify-center text-[13px] font-semibold transition-colors ${isDark ? 'bg-white text-black hover:bg-zinc-200' : 'bg-white text-[#003366] hover:bg-white/90'}`}>Get Quote — WhatsApp</a>
            </div>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className={`border-t ${isDark ? 'border-white/5 bg-[#080E1E]' : 'border-[#003366]/5 bg-white'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="flex flex-wrap justify-between gap-8 items-end mb-12">
              <div>
                <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>05 — Selected Projects</div>
                <h2 className={`mt-3 text-[32px] sm:text-[48px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>Work that ships.</h2>
              </div>
              <div className="flex gap-2">
                <span className={`px-3 py-1.5 rounded-full border text-[11px] mono uppercase ${isDark ? 'border-white/10 text-zinc-400' : 'border-[#003366]/10 text-[#003366]/60'}`}>6 Projects</span>
                <span className={`px-3 py-1.5 rounded-full border text-[11px] mono uppercase ${isDark ? 'border-white/10 text-zinc-400' : 'border-[#003366]/10 text-[#003366]/60'}`}>2024—2025</span>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {PROJECTS.map(p=>(
                <div key={p.title} className={`group rounded-[20px] border overflow-hidden flex flex-col transition-all hover:-translate-y-1.5 ${isDark ? 'bg-white/[0.03] border-white/10 hover:bg-white/[0.05]' : 'bg-white border-[#003366]/5 hover:shadow-[0_20px_50px_rgba(0,51,102,0.12)]'}`}>
                  <div className={`h-[200px] relative overflow-hidden bg-gradient-to-br ${p.color} p-6 flex flex-col justify-between`}>
                    <div className="flex justify-between items-start">
                      <span className="rounded-full bg-white/90 text-black px-3 py-1 text-[10px] font-bold mono uppercase tracking-wide">{p.cat}</span>
                      <span className="h-8 w-8 rounded-full bg-white/15 backdrop-blur border border-white/20 grid place-items-center text-white"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M7 17L17 7 M8 7h9v9"/></svg></span>
                    </div>
                    <div>
                      <div className="text-[28px] font-bold text-white leading-none tracking-tight opacity-90">{p.year}</div>
                      <div className="mt-2 h-1 w-12 bg-white/50 rounded-full" />
                    </div>
                    <div className="absolute inset-0 opacity-20 grid-bg pointer-events-none" />
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className={`text-[16px] font-semibold leading-tight tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>{p.title}</h3>
                    <p className={`mt-2.5 text-[13px] leading-[1.5] flex-1 ${isDark ? 'text-zinc-400' : 'text-[#222]/60'}`}>{p.desc}</p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {p.tags.map(t=>(
                        <span key={t} className={`px-2.5 py-1 rounded-full text-[10px] font-medium border mono uppercase tracking-wide ${isDark ? 'bg-white/5 border-white/10 text-zinc-400' : 'bg-[#F5F7FA] border-[#003366]/10 text-[#003366]/60'}`}>{t}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SOCIAL */}
        <section id="social" className={`${isDark ? 'bg-[#060E1E]' : 'bg-[#F5F7FA]'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-10 items-start">
              <div>
                <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>06 — Social & Personal Brand</div>
                <h2 className={`mt-3 text-[32px] sm:text-[48px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>Building <span className="text-[#00C2FF]">digitaljaipur</span><br/>in public.</h2>
                
                <div className={`mt-8 rounded-[24px] border overflow-hidden ${isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white border-[#003366]/5 shadow-[0_12px_32px_rgba(0,51,102,0.06)]'}`}>
                  <div className={`p-6 border-b flex items-center justify-between ${isDark ? 'border-white/5' : 'border-[#003366]/5'}`}>
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-gradient-to-br from-[#003366] to-[#00C2FF] grid place-items-center text-white font-bold">PS</div>
                      <div>
                        <div className={`text-[14px] font-semibold flex items-center gap-1.5 ${isDark ? 'text-white' : 'text-[#003366]'}`}>digitaljaipur.prem <span className="h-4 w-4 rounded-full bg-[#0066FF] grid place-items-center text-white"><svg width="10" height="10" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="2"><path d="M5 12l5 5l10-10"/></svg></span></div>
                        <div className={`mono text-[11px] ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Prem Sharma • Jaipur Creator</div>
                      </div>
                    </div>
                    <button className="h-8 px-4 rounded-full bg-[#0066FF] text-white text-[12px] font-semibold">Follow</button>
                  </div>

                  <div className={`grid grid-cols-3 divide-x py-4 text-center ${isDark ? 'divide-white/5' : 'divide-[#003366]/5'}`}>
                    {[{k:"127", l:"Posts"},{k:"3.2K", l:"Followers"},{k:"482", l:"Following"}].map(s=>(
                      <div key={s.l}><div className={`text-[18px] font-bold ${isDark ? 'text-white' : 'text-[#003366]'}`}>{s.k}</div><div className={`mono text-[10px] uppercase ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>{s.l}</div></div>
                    ))}
                  </div>

                  <div className="px-6 pb-2 flex gap-2 border-b border-dashed border-black/10 dark:border-white/10 overflow-x-auto">
                    {['feed','reels','photos','stories'].map(tab=>(
                      <button key={tab} onClick={()=>setInstaTab(tab)} className={`h-8 px-4 rounded-full text-[12px] font-medium capitalize border transition-colors whitespace-nowrap ${instaTab===tab ? (isDark ? 'bg-white text-black border-white' : 'bg-[#003366] text-white border-[#003366]') : (isDark ? 'bg-white/5 border-white/10 text-zinc-400' : 'bg-[#F5F7FA] border-[#003366]/10 text-[#003366]/60')}`}>{tab}</button>
                    ))}
                  </div>

                  <div className="p-3 grid grid-cols-3 gap-3">
                    {[1,2,3,4,5,6].map(i=>(
                      <div key={i} className={`aspect-square rounded-[14px] overflow-hidden relative group cursor-pointer ${i===2 && instaTab==='reels' ? 'ring-2 ring-[#00C2FF] ring-offset-2 ring-offset-transparent' : ''}`}>
                        <div className={`absolute inset-0 bg-gradient-to-br ${['from-[#003366] to-[#0055AA]','from-[#0055AA] to-[#00C2FF]','from-slate-800 to-[#003366]','from-[#0066FF] to-[#00C2FF]','from-[#001A33] to-[#003366]','from-[#003366] to-slate-900'][i-1]}`} />
                        <div className="absolute inset-0 opacity-30 grid-bg" />
                        <div className="absolute inset-0 flex items-center justify-center text-white/70 group-hover:text-white transition-colors">
                          {instaTab==='reels' && i%2===0 ? <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M8 5.14v14l11-7l-11-7z"/></svg> : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>}
                        </div>
                        <div className="absolute bottom-1.5 left-1.5 right-1.5 flex justify-between items-center text-[10px] text-white/80 mono">
                          <span className="flex items-center gap-1"><svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M12 21s-6.5-4.35-9-8.5C1.5 8.5 3 5 7 5c2 0 3 1 5 3 2-2 3-3 5-3 4 0 5.5 3.5 4 7.5-2.5 4.15-9 8.5-9 8.5z"/></svg> {120+i*37}</span>
                          {instaTab==='reels' && <span className="bg-black/50 px-1.5 py-0.5 rounded-full text-[9px]">15s</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className={`p-4 text-center mono text-[11px] ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Latest • Edited in Canva Pro + AI • Jaipur</div>
                </div>
              </div>

              <div className="space-y-5 lg:sticky lg:top-[96px]">
                <div className={`rounded-[20px] border p-7 ${isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white border-[#003366]/5 shadow-[0_12px_32px_rgba(0,51,102,0.06)]'}`}>
                  <div className={`mono text-[10px] uppercase tracking-widest ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Content Pillars</div>
                  <div className="mt-4 space-y-3">
                    {[
                      {t:"Govt Office Hacks", d:"Notesheet templates, RajKaj tips", p:40},
                      {t:"AI for Office Work", d:"Prompts that draft letters in 2 min", p:65},
                      {t:"Jaipur Diaries", d:"RUHS life, personal brand journey", p:30},
                    ].map(item=>(
                      <div key={item.t} className={`rounded-[12px] border p-4 ${isDark ? 'border-white/5 bg-[#060E1E]' : 'border-[#003366]/5 bg-[#F5F7FA]'}`}>
                        <div className="flex justify-between items-center">
                          <span className={`text-[13px] font-semibold ${isDark ? 'text-white' : 'text-[#003366]'}`}>{item.t}</span>
                          <span className="text-[11px] mono text-[#00C2FF]">{item.p}%</span>
                        </div>
                        <div className={`mt-1 text-[11px] ${isDark ? 'text-zinc-500' : 'text-[#003366]/60'}`}>{item.d}</div>
                        <div className={`mt-3 h-1.5 w-full rounded-full overflow-hidden ${isDark ? 'bg-white/5' : 'bg-[#003366]/10'}`}><div className="h-full bg-[#00C2FF] rounded-full" style={{width:`${item.p}%`}} /></div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className={`rounded-[20px] p-7 text-white relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#003366] to-[#0055AA]' : 'bg-[#003366]'}`}>
                  <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[#00C2FF]/20 blur-[20px]" />
                  <div className="relative">
                    <div className="text-[22px] font-semibold tracking-tight leading-tight">Want same branding?</div>
                    <div className="mt-2 text-[13px] leading-[1.5] text-white/70">I design Instagram kits, thumbnails & portfolio sites. Starting ₹1,999. Delivery in 48h.</div>
                    <a href="#contact" className="mt-5 inline-flex h-10 px-5 rounded-full bg-white text-[#003366] text-[13px] font-semibold items-center gap-2">Start Project <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14 M13 5l7 7-7 7"/></svg></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className={`border-t ${isDark ? 'border-white/5 bg-[#080E1E]' : 'border-[#003366]/5 bg-white'}`}>
          <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-20 lg:py-28">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-12 lg:gap-16">
              <div>
                <div className={`mono text-[11px] tracking-[0.2em] uppercase ${isDark ? 'text-[#7AD9FF]' : 'text-[#0055AA]'}`}>07 — Contact</div>
                <h2 className={`mt-3 text-[36px] sm:text-[52px] font-semibold tracking-tight leading-[0.9] ${isDark ? 'text-white' : 'text-[#003366]'}`}>Let's make<br/>it official.</h2>
                <p className={`mt-4 text-[15px] leading-[1.6] max-w-[400px] ${isDark ? 'text-zinc-400' : 'text-[#222]/60'}`}>For government drafting, portfolio sites, or AI workflow — WhatsApp is fastest. Email for official work.</p>

                <div className="mt-10 space-y-3">
                  {[
                    {icon:"M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6", label:"Email", value:"premsharma.9119@gmail.com", action:"mailto:premsharma.9119@gmail.com"},
                    {icon:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.68A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.77.63 2.61a2 2 0 0 1-.45 2.11L9 9a16 16 0 0 0 6 6l.54-.29a2 2 0 0 1 2.11-.45c.84.3 1.71.51 2.61.63A2 2 0 0 1 22 16.92z", label:"Phone / WhatsApp", value:"+91 78785 59853", action:"https://wa.me/917878559853"},
                    {icon:"M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", label:"Office", value:"RUHS CMS, Jaipur - 302033", action:"#"},
                  ].map(row=>(
                    <a key={row.label} href={row.action} className={`flex items-center gap-4 rounded-[14px] border p-4 group transition-colors ${isDark ? 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]' : 'bg-[#F5F7FA] border-[#003366]/5 hover:bg-white hover:shadow-[0_8px_24px_rgba(0,51,102,0.06)]'}`}>
                      <div className={`h-11 w-11 rounded-full grid place-items-center shrink-0 ${isDark ? 'bg-white text-black' : 'bg-[#003366] text-white group-hover:bg-[#0055AA]'} transition-colors`}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d={row.icon}/></svg></div>
                      <div>
                        <div className={`mono text-[10px] uppercase tracking-wide ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>{row.label}</div>
                        <div className={`text-[14px] font-medium ${isDark ? 'text-white' : 'text-[#003366]'}`}>{row.value}</div>
                      </div>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={`ml-auto opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all ${isDark ? 'text-white' : 'text-[#003366]'}`}><path d="M5 12h14 M13 5l7 7-7 7"/></svg>
                    </a>
                  ))}
                </div>

                <div className="mt-8 flex gap-3">
                  {[
                    {n:"Instagram", h:"IG", link:"#"},
                    {n:"LinkedIn", h:"IN", link:"#"},
                    {n:"GitHub", h:"GH", link:"#"},
                    {n:"WhatsApp", h:"WA", link:"https://wa.me/917878559853"},
                  ].map(s=>(
                    <a key={s.n} href={s.link} className={`h-11 w-11 rounded-full border grid place-items-center text-[12px] font-bold mono hover:scale-105 transition-transform ${isDark ? 'bg-white/5 border-white/10 text-zinc-300' : 'bg-white border-[#003366]/10 text-[#003366]'}`}>{s.h}</a>
                  ))}
                </div>
              </div>

              <div className={`rounded-[24px] border p-7 sm:p-8 ${isDark ? 'bg-white/[0.03] border-white/10 glass' : 'bg-[#F5F7FA] border-[#003366]/5'}`}>
                <div className="flex justify-between items-center mb-6">
                  <h3 className={`text-[18px] font-semibold tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>Send a message</h3>
                  <span className={`mono text-[10px] uppercase px-2.5 py-1 rounded-full border ${isDark ? 'border-white/10 text-zinc-500' : 'border-[#003366]/10 text-[#003366]/50'}`}>Response in 2h • Jaipur time</span>
                </div>

                {sent ? (
                  <div className="py-16 text-center">
                    <div className="h-16 w-16 mx-auto rounded-full bg-emerald-500/15 text-emerald-500 grid place-items-center"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12l5 5l10-10"/></svg></div>
                    <h4 className={`mt-4 text-[18px] font-semibold ${isDark ? 'text-white' : 'text-[#003366]'}`}>Message sent!</h4>
                    <p className={`mt-2 text-[13px] ${isDark ? 'text-zinc-400' : 'text-[#003366]/60'}`}>Thanks, {form.name}. I'll reply on WhatsApp/email within 2 hours.</p>
                    <button onClick={()=>setSent(false)} className={`mt-6 h-10 px-5 rounded-full text-[13px] font-medium border ${isDark ? 'border-white/10' : 'border-[#003366]/10'}`}>Send another</button>
                  </div>
                ) : (
                  <form onSubmit={(e)=>{e.preventDefault(); setSent(true);}} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className={`mono text-[10px] uppercase tracking-wide mb-1.5 block ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Full Name</label>
                        <input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="Prem Sharma" className={`w-full h-[44px] rounded-[12px] border px-4 text-[14px] outline-none focus:ring-2 focus:ring-[#00C2FF]/30 transition-all ${isDark ? 'bg-[#060E1E] border-white/10 text-white placeholder:text-zinc-600' : 'bg-white border-[#003366]/10 text-[#222] placeholder:text-[#003366]/30'}`} />
                      </div>
                      <div>
                        <label className={`mono text-[10px] uppercase tracking-wide mb-1.5 block ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Email Address</label>
                        <input required type="email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="prem@example.com" className={`w-full h-[44px] rounded-[12px] border px-4 text-[14px] outline-none focus:ring-2 focus:ring-[#00C2FF]/30 transition-all ${isDark ? 'bg-[#060E1E] border-white/10 text-white placeholder:text-zinc-600' : 'bg-white border-[#003366]/10 text-[#222] placeholder:text-[#003366]/30'}`} />
                      </div>
                    </div>
                    <div>
                      <label className={`mono text-[10px] uppercase tracking-wide mb-1.5 block ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Subject</label>
                      <select value={form.subject} onChange={e=>setForm({...form, subject:e.target.value})} className={`w-full h-[44px] rounded-[12px] border px-4 text-[14px] outline-none focus:ring-2 focus:ring-[#00C2FF]/30 ${isDark ? 'bg-[#060E1E] border-white/10 text-white' : 'bg-white border-[#003366]/10 text-[#222]'}`}>
                        <option value="">Select service...</option>
                        <option>Official Letter / Notesheet</option>
                        <option>Portfolio Website</option>
                        <option>Resume Design</option>
                        <option>Instagram Branding</option>
                        <option>AI Prompt / Automation</option>
                      </select>
                    </div>
                    <div>
                      <label className={`mono text-[10px] uppercase tracking-wide mb-1.5 block ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>Message</label>
                      <textarea required value={form.message} onChange={e=>setForm({...form, message:e.target.value})} placeholder="Tell me about your requirement, deadline and budget..." rows={5} className={`w-full rounded-[12px] border p-4 text-[14px] outline-none focus:ring-2 focus:ring-[#00C2FF]/30 resize-none ${isDark ? 'bg-[#060E1E] border-white/10 text-white placeholder:text-zinc-600' : 'bg-white border-[#003366]/10 text-[#222] placeholder:text-[#003366]/30'}`} />
                    </div>
                    <button type="submit" className="w-full h-[48px] rounded-full bg-[#0066FF] hover:bg-[#0055CC] text-white text-[14px] font-semibold shadow-[0_8px_24px_rgba(0,102,255,0.25)] transition-colors flex items-center justify-center gap-2">
                      Send Message <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 2L11 13 M22 2l-7 20l-4-9l-9-4l20-7z"/></svg>
                    </button>
                    <div className={`text-center mono text-[10px] ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Secure • No spam • Direct to premsharma.9119@gmail.com</div>
                  </form>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className={`border-t ${isDark ? 'border-white/5 bg-[#060E1E]' : 'border-[#003366]/5 bg-[#F5F7FA]'}`}>
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-12">
          <div className="flex flex-col lg:flex-row justify-between gap-10">
            <div>
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-[10px] bg-[#003366] grid place-items-center text-white font-bold text-[14px]">PS</div>
                <span className={`font-semibold tracking-tight ${isDark ? 'text-white' : 'text-[#003366]'}`}>digitaljaipur.prem.in</span>
              </div>
              <div className={`mt-4 max-w-[320px] text-[13px] leading-[1.6] ${isDark ? 'text-zinc-400' : 'text-[#222]/60'}`}>
                Official portfolio of Prem Sharma — Government Professional, AI Creator, Web Developer at RUHS CMS, Jaipur. Combining administration with innovation.
              </div>
              <div className="mt-5 flex gap-2">
                {[
                  {c:"#003366", n:"Primary"},
                  {c:"#0055AA", n:"Secondary"},
                  {c:"#00C2FF", n:"Accent"},
                  {c:"#0066FF", n:"Button"},
                ].map(col=>(
                  <div key={col.c} className="flex items-center gap-1.5">
                    <div className="h-3 w-3 rounded-full" style={{background:col.c}} />
                    <span className={`mono text-[10px] ${isDark ? 'text-zinc-500' : 'text-[#003366]/50'}`}>{col.c}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-10">
              <div>
                <div className={`mono text-[11px] uppercase tracking-widest mb-4 ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Sitemap</div>
                <div className="grid gap-2.5">
                  {NAV_ITEMS.slice(0,4).map(i=>(
                    <a key={i.id} href={`#${i.id}`} className={`text-[13px] hover:underline ${isDark ? 'text-zinc-400 hover:text-white' : 'text-[#003366]/70 hover:text-[#003366]'}`}>{i.label}</a>
                  ))}
                </div>
              </div>
              <div>
                <div className={`mono text-[11px] uppercase tracking-widest mb-4 ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Services</div>
                <div className="grid gap-2.5">
                  {["Drafting","Notesheet","Portfolio","AI Prompts"].map(t=>(
                    <span key={t} className={`text-[13px] ${isDark ? 'text-zinc-400' : 'text-[#003366]/70'}`}>{t}</span>
                  ))}
                </div>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <div className={`mono text-[11px] uppercase tracking-widest mb-4 ${isDark ? 'text-zinc-500' : 'text-[#003366]/40'}`}>Connect</div>
                <div className={`text-[13px] leading-[1.6] ${isDark ? 'text-zinc-400' : 'text-[#003366]/70'}`}>
                  Jaipur, Rajasthan 302033<br/>
                  premsharma.9119@gmail.com<br/>
                  +91 78785 59853
                </div>
              </div>
            </div>
          </div>

          <div className={`mt-12 pt-6 border-t flex flex-col sm:flex-row justify-between gap-3 items-center mono text-[11px] ${isDark ? 'border-white/5 text-zinc-500' : 'border-[#003366]/5 text-[#003366]/40'}`}>
            <span>© 2026 Prem Sharma — All official work follows Govt of Rajasthan protocols.</span>
            <span className="flex items-center gap-1.5">Made with <span className="text-[#FF3B5C]">❤</span> by Prem Sharma • digitaljaipur.prem.in</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
